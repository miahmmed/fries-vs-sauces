// Fries vs. Sauces — minimal 3D TD built with Three.js
// Runs on iPhone Safari. Add to Home Screen for app-like experience.

/* ------------------------------------------------------------------
   Game Config
------------------------------------------------------------------ */
const FRIES = [
  { key: 'Regular',  cost: 40,  range: 5.2,  dps: 10,  rof: 0.6 },
  { key: 'Curly',    cost: 60,  range: 4.5,  dps: 18,  rof: 0.8 },
  { key: 'Waffle',   cost: 75,  range: 7.5,  dps: 28,  rof: 1.2 },
  { key: 'Crinkle',  cost: 70,  range: 5.5,  dps: 10,  rof: 0.5, slow: 0.6 },
  { key: 'Cheese',   cost: 80,  range: 4.2,  dps: 35,  rof: 1.3, splash: 2.2 },
  { key: 'Chili',    cost: 85,  range: 5.0,  dps: 14,  rof: 0.7, burn: 4 },
  { key: 'SweetPot', cost: 55,  range: 4.0,  dps: 0,   rof: 0.0, heal: 8 },
  { key: 'Garlic',   cost: 65,  range: 4.5,  dps: 8,   rof: 0.9, weaken: 0.8 },
  { key: 'Butter',   cost: 70,  range: 4.0,  dps: 0,   rof: 0.0, aura: 1.2 },
  { key: 'Mega',     cost: 120, range: 8.5,  dps: 70,  rof: 1.6 }
];

const SAUCES = [
  { key: 'Ketchup',     hp: 40,  speed: 1.1 },
  { key: 'Mustard',     hp: 35,  speed: 1.7 },
  { key: 'BBQ',         hp: 75,  speed: 1.0, sticky: true },
  { key: 'Mayo',        hp: 120, speed: 0.8, tank: true },
  { key: 'Sriracha',    hp: 45,  speed: 1.6, phase: true },
  { key: 'Tartar',      hp: 60,  speed: 1.2, split: 2 },
  { key: 'Soy',         hp: 70,  speed: 1.1, wave: true },
  { key: 'Buffalo',     hp: 65,  speed: 1.3, burnAura: true },
  { key: 'HoneyMust',   hp: 55,  speed: 1.1, healAura: true },
  { key: 'GigaSauce',   hp: 500, speed: 0.7, boss: true }
];

const WAVES = 10;

/* ------------------------------------------------------------------
   Simple Utilities
------------------------------------------------------------------ */
function lerp(a,b,t){ return a + (b-a)*t; }
function clamp(x,a,b){ return Math.max(a, Math.min(b,x)); }
function dist(a,b){ return a.distanceTo(b); }

function showMsg(txt, ms=1400){
  const el = document.getElementById('msg');
  el.textContent = txt;
  el.style.display = 'block';
  clearTimeout(showMsg.t);
  showMsg.t = setTimeout(()=> el.style.display='none', ms);
}

/* ------------------------------------------------------------------
   Scene Setup
------------------------------------------------------------------ */
let scene, camera, renderer, controls, clock;
let raycaster = new THREE.Raycaster();
let mouse = new THREE.Vector2(1,1);

let oil = 120;
let lives = 20;
let wave = 0;

const oilEl = document.getElementById('oil');
const livesEl = document.getElementById('lives');
const waveEl = document.getElementById('wave');

const slots = [];
const towers = [];
const enemies = [];
const bullets = [];

const enemyPath = []; // array of Vector3 points along pizza to crust

function updateHUD(){
  oilEl.textContent = Math.floor(oil);
  livesEl.textContent = lives;
  waveEl.textContent = wave;
}

/* ------------------------------------------------------------------
   Build Pizza Map w/ Path + Slots
------------------------------------------------------------------ */
function buildMap(){
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x111111);

  camera = new THREE.PerspectiveCamera(60, innerWidth/innerHeight, 0.1, 1000);
  camera.position.set(10, 12, 16);

  renderer = new THREE.WebGLRenderer({ antialias:true, alpha:false });
  renderer.setSize(innerWidth, innerHeight);
  document.body.appendChild(renderer.domElement);

  controls = new THREE.OrbitControls(camera, renderer.domElement);
  controls.enablePan = false;
  controls.minPolarAngle = 0.5;
  controls.maxPolarAngle = 1.3;
  controls.target.set(0,0,0);
  controls.update();

  clock = new THREE.Clock();

  // Lights
  const hemi = new THREE.HemisphereLight(0xffffff, 0x303030, 1.1);
  scene.add(hemi);
  const dir = new THREE.DirectionalLight(0xffffff, 0.9);
  dir.position.set(5,10,7);
  scene.add(dir);

  // Pizza base (disc)
  const pizzaGeo = new THREE.CylinderGeometry(8,8,0.6, 48);
  const pizzaMat = new THREE.MeshStandardMaterial({ color: 0xD99B3A, roughness:0.9, metalness:0.0 });
  const pizza = new THREE.Mesh(pizzaGeo, pizzaMat);
  pizza.position.y = -0.3;
  scene.add(pizza);

  // Toppings dots
  const toppingMat = new THREE.MeshStandardMaterial({ color: 0xAA2A2A });
  for(let i=0;i<40;i++){
    const t = new THREE.Mesh(new THREE.SphereGeometry(0.18, 16, 16), toppingMat);
    t.position.set((Math.random()-0.5)*12, 0.1, (Math.random()-0.5)*12);
    if (t.position.length() < 7.5) scene.add(t);
  }

  // Plate
  const plate = new THREE.Mesh(new THREE.CylinderGeometry(9.5,9.5,0.3,48), new THREE.MeshStandardMaterial({ color: 0xE0E0E0, metalness:0.1, roughness:0.8 }));
  plate.position.y = -0.8;
  scene.add(plate);

  // Path: spiral-ish curve into center
  const pathPoints = [];
  const turns = 2.0;
  const steps = 220;
  for(let i=0;i<=steps;i++){
    const t = i/steps;
    const r = lerp(7.2, 0.4, t);
    const ang = t * turns * Math.PI * 2 + 0.6;
    const x = Math.cos(ang) * r;
    const z = Math.sin(ang) * r;
    pathPoints.push(new THREE.Vector3(x, 0, z));
  }
  for(const p of pathPoints) enemyPath.push(p);

  // Visualize path (thin tube)
  const pathGeo = new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pathPoints), 240, 0.08, 8, false);
  const pathMat = new THREE.MeshStandardMaterial({ color: 0x333333, roughness:0.6 });
  const pathMesh = new THREE.Mesh(pathGeo, pathMat);
  scene.add(pathMesh);

  // Tower slots around the path
  const slotMat = new THREE.MeshStandardMaterial({ color: 0x3AA74B });
  for(let i=0;i<22;i++){
    const idx = Math.floor(i*(pathPoints.length-1)/22);
    const p = pathPoints[idx];
    const n = idx < pathPoints.length-1 ? pathPoints[idx+1].clone().sub(p).normalize() : new THREE.Vector3(1,0,0);
    const perp = new THREE.Vector3(-n.z, 0, n.x).normalize();
    const pos = p.clone().addScaledVector(perp, 1.2 + Math.random()*0.9);
    const slot = new THREE.Mesh(new THREE.CylinderGeometry(0.45,0.45,0.2, 16), slotMat);
    slot.position.copy(pos);
    slot.userData = { type: 'slot', occupied: false };
    scene.add(slot);
    slots.push(slot);
  }

  window.addEventListener('resize', ()=>{
    camera.aspect = innerWidth/innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
  });

  renderer.domElement.addEventListener('pointerdown', onPointerDown);
}

/* ------------------------------------------------------------------
   Towers & Enemies
------------------------------------------------------------------ */
function makeFryMesh(kind){
  // Fries are yellow cylinders; some variants tweak geometry
  const baseColor = 0xEACA44;
  const mat = new THREE.MeshStandardMaterial({ color: baseColor, roughness:0.6 });
  const h = 1.2 + (Math.random()*0.2);
  const geo = new THREE.CylinderGeometry(0.2, 0.25, h, 12);
  const m = new THREE.Mesh(geo, mat);
  m.castShadow = true;
  m.receiveShadow = true;
  // topper
  const tip = new THREE.Mesh(new THREE.ConeGeometry(0.18, 0.25, 12), new THREE.MeshStandardMaterial({ color: 0xCCAA22 }));
  tip.position.y = h/2 + 0.2;
  m.add(tip);
  m.userData.kind = kind;
  return m;
}

function makeSauceMesh(def){
  // Sauces are blobby spheres with different colors
  const colors = {
    Ketchup: 0xC72222,
    Mustard: 0xE3C212,
    BBQ: 0x8B3A1A,
    Mayo: 0xF1F1E0,
    Sriracha: 0xEB4A2A,
    Tartar: 0xE6F2D1,
    Soy: 0x4B2E1C,
    Buffalo: 0xD44F2E,
    HoneyMust: 0xD9B83A,
    GigaSauce: 0x7A0F0F
  };
  const mat = new THREE.MeshStandardMaterial({ color: colors[def.key] || 0x999999, roughness:0.3, metalness:0.0 });
  const r = def.boss ? 0.6 : 0.45;
  const geo = new THREE.SphereGeometry(r, 20, 20);
  const m = new THREE.Mesh(geo, mat);
  return m;
}

function addTower(slot, fryDef){
  if (slot.userData.occupied) { showMsg('Slot occupied'); return; }
  if (oil < fryDef.cost) { showMsg('Not enough oil'); return; }
  oil -= fryDef.cost;

  const mesh = makeFryMesh(fryDef.key);
  mesh.position.copy(slot.position);
  mesh.userData = {
    slot,
    def: fryDef,
    cooldown: 0
  };
  towers.push(mesh);
  scene.add(mesh);
  slot.userData.occupied = true;
  updateHUD();
}

function spawnEnemy(def){
  const mesh = makeSauceMesh(def);
  const ud = {
    def,
    hp: def.hp,
    t: 0, // position along path [0..1]
    speed: def.speed,
    alive: true,
    slowFactor: 1,
    burn: 0,
    weaken: 1
  };
  mesh.position.copy(enemyPath[0]);
  mesh.userData = ud;
  enemies.push(mesh);
  scene.add(mesh);
}

function dealDamage(enemy, amount){
  enemy.userData.hp -= amount * enemy.userData.weaken;
  if (enemy.userData.hp <= 0 && enemy.userData.alive){
    enemy.userData.alive = false;
    oil += 8;
    scene.remove(enemy);
    enemies.splice(enemies.indexOf(enemy),1);
    updateHUD();
  }
}

/* ------------------------------------------------------------------
   UI: Fry Palette
------------------------------------------------------------------ */
let selectedFryIndex = 0;
function buildUI(){
  const ui = document.getElementById('ui');
  ui.innerHTML='';

  FRIES.forEach((f,i)=>{
    const btn = document.createElement('button');
    btn.textContent = `${i+1}. ${f.key} (${f.cost})`;
    if (i%2===1) btn.classList.add('secondary');
    btn.onclick = ()=>{
      selectedFryIndex = i;
      showMsg(`Selected ${f.key}`);
    };
    ui.appendChild(btn);
  });

  const sellBtn = document.createElement('button');
  sellBtn.textContent = 'Sell (50%)';
  sellBtn.onclick = ()=>{
    // pick nearest tower to center of screen and sell
    if (!towers.length) return;
    const t = towers[towers.length-1];
    oil += Math.floor(t.userData.def.cost*0.5);
    t.userData.slot.userData.occupied = false;
    scene.remove(t);
    towers.pop();
    updateHUD();
  };
  ui.appendChild(sellBtn);
}

/* ------------------------------------------------------------------
   Input
------------------------------------------------------------------ */
function getIntersect(pos){
  raycaster.setFromCamera(pos, camera);
  const list = [...slots];
  return raycaster.intersectObjects(list, false)[0];
}

function onPointerDown(ev){
  const rect = renderer.domElement.getBoundingClientRect();
  mouse.x = ((ev.clientX - rect.left)/rect.width)*2 - 1;
  mouse.y = -((ev.clientY - rect.top)/rect.height)*2 + 1;
  const hit = getIntersect(mouse);
  if (hit && hit.object.userData.type === 'slot'){
    addTower(hit.object, FRIES[selectedFryIndex]);
  }
}

/* ------------------------------------------------------------------
   Waves
------------------------------------------------------------------ */
function startNextWave(){
  if (wave >= WAVES) return;
  wave++;
  updateHUD();
  const mix = [];
  // ramp difficulty
  for(let i=0;i<6+wave*2;i++){
    const idx = Math.min(SAUCES.length-1, Math.floor(Math.random()* (Math.min(2+wave, SAUCES.length))));
    mix.push(SAUCES[idx]);
  }
  if (wave === WAVES) mix.push(SAUCES[SAUCES.length-1]); // Boss
  // schedule spawns
  let i=0;
  const timer = setInterval(()=>{
    if (i>=mix.length){ clearInterval(timer); return; }
    spawnEnemy(mix[i++]);
  }, Math.max(240 - wave*10, 80));
}

/* ------------------------------------------------------------------
   Game Loop
------------------------------------------------------------------ */
function update(dt){
  // Enemies movement
  for(const e of [...enemies]){
    const ud = e.userData;
    if (!ud.alive) continue;
    ud.slowFactor = 1; // reset per-frame, applied by towers
    ud.weaken = 1;

    // progress along path
    ud.t += (ud.speed * dt) / enemyPath.length;
    const idx = Math.floor(ud.t * (enemyPath.length-1));
    if (idx >= enemyPath.length-1){
      // reached base
      lives -= (ud.def.boss? 5 : 1);
      updateHUD();
      scene.remove(e);
      enemies.splice(enemies.indexOf(e),1);
      if (lives <= 0){ gameOver(false); }
      continue;
    }
    const p = enemyPath[idx];
    e.position.copy(p);
  }

  // Towers: attack closest enemy in range
  for(const t of towers){
    const def = t.userData.def;
    if (def.heal){
      // heal nearby towers (no HP system here => buff oil slightly as "refund" over time)
      t.userData.cooldown -= dt;
      if (t.userData.cooldown <= 0){
        oil += 0.5;
        t.userData.cooldown = 1.2;
        updateHUD();
      }
      continue;
    }
    // aura
    if (def.aura){
      for(const other of towers){
        if (other===t) continue;
        if (other.position.distanceTo(t.position) < def.range){
          other.userData.dmgBoost = def.aura;
        }
      }
    }

    t.userData.cooldown -= dt;
    if (t.userData.cooldown > 0) continue;

    // find target
    let target=null, best=1e9;
    for(const e of enemies){
      const d = e.position.distanceTo(t.position);
      if (d < def.range && d < best){
        best = d; target = e;
      }
    }
    if (!target) continue;

    // fire
    const dmgBoost = t.userData.dmgBoost || 1;
    const dmg = def.dps * dmgBoost;
    dealDamage(target, dmg);
    // apply ailments
    if (def.slow) target.userData.slowFactor = Math.min(target.userData.slowFactor, def.slow);
    if (def.weaken) target.userData.weaken = Math.min(target.userData.weaken, def.weaken);
    if (def.burn){ target.userData.burn = Math.max(target.userData.burn, def.burn); }

    // simple visual bullet
    const b = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8,8), new THREE.MeshStandardMaterial({ color:0xffffff }));
    b.position.copy(t.position).add(new THREE.Vector3(0,0.6,0));
    b.userData = { life: 0.2 };
    bullets.push(b);
    scene.add(b);

    t.userData.cooldown = def.rof;
  }

  // Bullet life
  for(const b of [...bullets]){
    b.userData.life -= dt;
    b.position.y += dt*4;
    if (b.userData.life <= 0){
      scene.remove(b); bullets.splice(bullets.indexOf(b),1);
    }
  }

  // Burns DoT
  for(const e of enemies){
    if (e.userData.burn > 0){
      e.userData.burn -= dt;
      dealDamage(e, 4*dt);
    }
  }

  // Win condition
  if (wave === WAVES && enemies.length === 0){
    gameOver(true);
  }
}

let running = false;
function gameOver(win){
  running = false;
  showMsg(win? 'You Win! 🍕' : 'Pizza ruined! 💥');
  document.getElementById('overlay').classList.remove('hidden');
  const btn = document.getElementById('startBtn');
  btn.textContent = win? 'Play Again' : 'Retry';
}

function loop(){
  requestAnimationFrame(loop);
  const dt = Math.min(clock.getDelta(), 0.05);
  if (running) update(dt);
  renderer.render(scene, camera);
}

function startGame(){
  // reset
  oil = 120; lives = 20; wave = 0;
  updateHUD();
  // cleanup enemies/towers if replay
  for(const e of [...enemies]){ scene.remove(e); enemies.splice(enemies.indexOf(e),1); }
  for(const t of [...towers]){ t.userData.slot.userData.occupied=false; scene.remove(t); towers.splice(towers.indexOf(t),1); }

  running = true;
  // kickoff waves with delays
  let w = 0;
  const waveTimer = setInterval(()=>{
    if (!running){ clearInterval(waveTimer); return; }
    if (w>=WAVES){ clearInterval(waveTimer); return; }
    startNextWave();
    w++;
  }, 5500);
}

// Boot
document.getElementById('startBtn').addEventListener('click', ()=>{
  document.getElementById('overlay').classList.add('hidden');
  if (!scene) { buildMap(); buildUI(); clock = new THREE.Clock(); loop(); }
  startGame();
});
